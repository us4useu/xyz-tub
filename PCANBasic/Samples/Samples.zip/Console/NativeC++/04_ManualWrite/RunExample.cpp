#include "04_ManualWrite.h"

int main()
{
    ManualWrite start;
}