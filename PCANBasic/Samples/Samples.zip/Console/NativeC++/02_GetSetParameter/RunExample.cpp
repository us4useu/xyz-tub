#include "02_GetSetParameter.h"

int main()
{
    GetSetParameter start;
}