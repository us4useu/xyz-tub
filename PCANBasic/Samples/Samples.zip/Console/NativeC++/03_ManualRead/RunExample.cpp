#include "03_ManualRead.h"

int main()
{
    ManualRead start;
}