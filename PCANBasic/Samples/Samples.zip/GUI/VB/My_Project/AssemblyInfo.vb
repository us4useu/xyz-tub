﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("PCAN-Basic Sample")> 
<Assembly: AssemblyDescription("PCAN-Basic sample Application")> 
<Assembly: AssemblyCompany("PEAK-System Technik GmbH")> 
<Assembly: AssemblyProduct("PCAN-Basic 4.0")> 
<Assembly: AssemblyCopyright("Copyright ©  2015")> 
<Assembly: AssemblyTrademark("PCAN")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("60ee0529-6ada-458f-9a3f-7525ec099e4c")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("4.0.1.0")> 
<Assembly: AssemblyFileVersion("4.0.1.0")> 
